//
//  CPUStressTestApp.swift
//  CPUStressTest
//
//  Created by Ranjan on 15/03/26.
//

import SwiftUI

@main
struct CPUStressTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
