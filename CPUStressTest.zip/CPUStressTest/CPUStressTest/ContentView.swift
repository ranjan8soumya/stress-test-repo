import SwiftUI

struct ContentView: View {
    @State private var isRunning = false
    
    var body: some View {
        VStack(spacing: 30) {
            Text("CPU Stress Test")
                .font(.largeTitle)
            
            Button(action: {
                isRunning.toggle()
                if isRunning { startStressTest() }
            }) {
                Text(isRunning ? "STOP TEST" : "START CALCULATION")
                    .fontWeight(.bold)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isRunning ? Color.red : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            .padding(.horizontal)
            
            if isRunning {
                ProgressView("Calculating...")
            }
        }
    }

    func startStressTest() {
        DispatchQueue.global(qos: .userInteractive).async {
                while self.isRunning {
                    // Adding this print forces the profiler to see the call clearly
                    print("Stressing...")
                    self.performMathOperation()
                }
            }
    }

    @inline(never) // Forces the name to appear in the Call Tree
    func performMathOperation() {
        var result = 0.0
        for i in 0..<10_000_000 {
            result += sin(Double(i)) * cos(Double(i))
            result += tan(Double(i)) / (Double(i) + 1.0)
        }
    }
}

